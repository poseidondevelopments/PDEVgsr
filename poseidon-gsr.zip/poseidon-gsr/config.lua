-- Poseidon GSR Config
Config                          = {}     
Config.clearGSR = 30 
Config.clearGSRinWater          = 0.5    


